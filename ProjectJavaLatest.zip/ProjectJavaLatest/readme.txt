Hi Daryl
Just a quick outline of the application.
All CRUD operations are working ok. I have not had time to handle exceptions on some of the screens.
I have included a test case whereby I have shown a Failed test on a non-integer input on the initial Menu.
I have a search filter on each domain. On Drivers it requests a Drivers Team via entering the ID.
On Teams it shows a Teams Drivers via entering the ID. Ellipsis are working along with dynamic columns.
My "Word" skills are a bit rusty so the diagrams are not where I would like them to be. Couldn't get my head around draw.io.
I have a draft Methods list, which is included but have not had time to finish it. Hopefully this helps.
Regards
Gary Wheeler

