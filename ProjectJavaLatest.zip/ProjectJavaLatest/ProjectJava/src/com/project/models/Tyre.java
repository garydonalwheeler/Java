package com.project.models;

 /**
  * This is the Tyre Enum method.
  * @author Gary Wheeler
  */

public enum Tyre {
    Bridgestone,
    Goodyear,
    Michelin,
    Pirelli
}